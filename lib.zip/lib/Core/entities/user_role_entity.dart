
enum UserRole {
  traveler,
  driver,
}
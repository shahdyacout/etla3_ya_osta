
enum UserRole {
  
  traveler,
  driver,
}
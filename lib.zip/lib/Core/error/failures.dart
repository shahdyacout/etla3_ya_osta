abstract class Failure {
  final String message;
  const Failure(this.message);
}

// مفيش انترنت
class NetworkFailure extends Failure {
  const NetworkFailure() : super('No internet connection');
}

// خطأ عام من Firebase
class ServerFailure extends Failure {
  const ServerFailure([super.message = 'Something went wrong']);
}

// خطأ في البيانات المحلية
class CacheFailure extends Failure {
  const CacheFailure() : super('Local data error');
}

// input غلط من المستخدم
class InvalidInputFailure extends Failure {
  const InvalidInputFailure(super.message);
}

<<<<<<< HEAD
// المستخدم مش logged in
class AuthFailure extends Failure {
  const AuthFailure() : super('User not authenticated');
}

// الرصيد مش كفاية للسحب
class InsufficientBalanceFailure extends Failure {
  const InsufficientBalanceFailure() : super('Insufficient balance');
=======
abstract class Either<L, R> {
  const Either();
  T fold<T>(T Function(L l) leftFn, T Function(R r) rightFn);
}

class Left<L, R> extends Either<L, R> {
  final L value;
  const Left(this.value);
  @override
  T fold<T>(T Function(L l) leftFn, T Function(R r) rightFn) => leftFn(value);
}

class Right<L, R> extends Either<L, R> {
  final R value;
  const Right(this.value);
  @override
  T fold<T>(T Function(L l) leftFn, T Function(R r) rightFn) => rightFn(value);
>>>>>>> aef1614e4222a53b551286a2bf42151a878cb93a
}